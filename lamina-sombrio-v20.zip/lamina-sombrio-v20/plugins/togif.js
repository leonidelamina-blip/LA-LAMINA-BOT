// 🩸 Plugin .togif — FIGURINHAS
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['togif'], cat: 'FIGURINHAS',
  run: c => executar('fn', "togif", c)
};
