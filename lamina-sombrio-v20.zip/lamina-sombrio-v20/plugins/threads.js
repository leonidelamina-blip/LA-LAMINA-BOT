// 🩸 Plugin .threads — DOWNLOAD
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['threads'], cat: 'DOWNLOAD',
  run: c => executar('dl', {"p":"threads","k":"v"}, c)
};
