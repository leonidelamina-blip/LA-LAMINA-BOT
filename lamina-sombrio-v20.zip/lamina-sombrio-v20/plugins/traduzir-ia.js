// 🩸 Plugin .traduzir-ia — IA
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['traduzir-ia'], cat: 'IA',
  run: c => executar('ia', "Traduza para português: ", c)
};
