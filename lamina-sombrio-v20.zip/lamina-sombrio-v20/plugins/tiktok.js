// 🩸 Plugin .tiktok — DOWNLOAD
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['tiktok'], cat: 'DOWNLOAD',
  run: c => executar('dl', {"p":"tiktok","k":"v"}, c)
};
