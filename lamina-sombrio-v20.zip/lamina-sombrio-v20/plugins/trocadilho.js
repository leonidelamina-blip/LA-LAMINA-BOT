// 🩸 Plugin .trocadilho — DIVERSAO
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['trocadilho'], cat: 'DIVERSAO',
  run: c => executar('rnd', ["Esse bot não é fraco, é só... Uchi-ha.","Sou ninja: me pego sempre no Naru-todo.","Choveu? Vá de Chidori-chuva."], c)
};
