// 🩸 Plugin .toimg — FIGURINHAS
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['toimg'], cat: 'FIGURINHAS',
  run: c => executar('fn', "toimg", c)
};
