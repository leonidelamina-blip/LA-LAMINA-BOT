// 🩸 Plugin .traduzir — UTILIDADES
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['traduzir'], cat: 'UTILIDADES',
  run: c => executar('web', {"q":1,"p":"responseData.translatedText","u":"https://api.mymemory.translated.net/get?q={q}&langpair=Autodetect|pt"}, c)
};
