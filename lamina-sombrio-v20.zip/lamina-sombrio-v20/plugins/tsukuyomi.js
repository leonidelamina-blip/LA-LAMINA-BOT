// 🩸 Plugin .tsukuyomi — ANIME
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['tsukuyomi'], cat: 'ANIME',
  run: c => executar('txt', ["🌑 Tsukuyomi — ilusão onde eu controlo o tempo.","Três dias de tortura em um segundo."], c)
};
