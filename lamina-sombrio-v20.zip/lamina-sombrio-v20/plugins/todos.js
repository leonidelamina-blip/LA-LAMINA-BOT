// 🩸 Plugin .todos — GRUPO
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['todos'], cat: 'GRUPO',
  run: c => executar('fn', "todos", c)
};
