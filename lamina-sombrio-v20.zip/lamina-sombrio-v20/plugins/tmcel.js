// 🩸 Plugin .tmcel — VENDAS
const { executar } = require('../lib/tipos');
module.exports = {
  cmd: ['tmcel'], cat: 'VENDAS',
  run: c => executar('cfg', "tmcel", c)
};
